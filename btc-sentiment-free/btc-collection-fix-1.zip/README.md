# Collection fix 1

Put collect_balanced.py alongside your existing btc_sentiment.py. No replacement
of that file is needed. Python standard library only; use conda activate binbot.
Stop any existing collector before running this companion.

Commands from the project directory:

    python collect_balanced.py coverage
    python collect_balanced.py plan --limit 100
    python collect_balanced.py collect --limit 100

Use --db PATH and --cache PATH if your existing project uses nondefault locations.
Repeat collect to append new articles. Existing articles and scores are preserved.
Use this collector instead of the old `btc_sentiment.py collect` command.
--limit counts attempted URLs, not successful articles.

Scheduling rotates sources and month-hint buckets, retaining attempt counts across
runs for the specified date range. SHA-256 URL ordering removes alphabetical
ordering within each bucket. Out-of-range/missing hints get an unknown bucket;
only extracted publication timestamps determine inclusion. Previously collected
articles are not rebalanced or removed. Fair scheduling cannot guarantee balanced
successful downloads, genuine publication months, or representative coverage.

Failed URLs are skipped by default (including old article errors). To retry them:

    python collect_balanced.py collect --limit 100 --retry-failed

Fresh URLs within a source precede retries. Failures and out-of-period outcomes are
recorded in collection_attempts_v2. Existing visited records are not used because
they do not record the date range; a small amount of old out-of-period work may be
revisited once. Do not run multiple collectors concurrently.

If a source has zero candidates, run discovery with the existing script (see
`python btc_sentiment.py discover --help`) and inspect its source errors. This
patch does not change sitemap discovery or URL-keyword screening. Publisher access
has not been tested live in this delivery. Empty months remain missing, not neutral.

Do not rescore the expanded dataset yet: classification fixes are the next step.

Tests, after placing files alongside btc_sentiment.py:

    python -m unittest test_collection -v
